/*
	Simple class that builds and stores a single set of account history data.  One instance of this class represents one 
*/

class AccountHistory
{
	private int recordLength = 36;

	private String balance;
	private String billed;
	private String amount1;
	private String paid;
	private String amount2;


	public AccountHistory(String rawData){

		// Check for a valid buffer length
		if(rawData.length() != recordLength){
			System.err.println("Invalid record length of " + rawData.length() + 
					". Cannot create new AccountHistory object - closing");
			System.exit(1);
		}

		// Extract data into variables
		balance = rawData.substring(0, 8);			//Balance(8) Account Balance - *** 0-7 ***

		billed = rawData.substring(8, 10) + "-" +		//BMonth(2) Month(2) Day(2) - *** 8-13 ***
					rawData.substring(10, 12) + "-" +
					rawData.substring(12, 14);

		amount1 = rawData.substring(14, 22);			//BAmount(8) Amount of Balance - *** 14-21 ***

		paid =	rawData.substring(22, 24) + "-" +		//PDay(2) PMonth(2) PYear(2) - *** 22-27 ***
					rawData.substring(24, 26) + "-" +
					rawData.substring(26, 28);

		amount2 = rawData.substring(28, 36);			// PAmount(8) Payment Amount - *** 28-36 ***

	}


	public String balance(){
		return balance;
	}


	public String billed(){
		return billed;
	}


	public String amount1(){
		return amount1;
	}


	public String paid(){
		return paid;
	}


	public String amount2(){
		return amount2;
	}

}	// Class Ends
