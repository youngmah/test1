/*

	This class extends the basic JTextField to set up desired features.
	The new constructor takes the desired width as an argument in integer form.
	The height of all instances of this class are the same.

	Author - Steve Young. March 1999

*/

import javax.swing.JTextField;
import java.awt.Dimension;
import java.awt.Color;

class DisplayField extends JTextField {
	private final int height = 5;

	public DisplayField(int width, Color background) {
		// As this field is for display only, make it non editable
		setEditable(false);

		setBackground(background);

		setPreferredSize(new Dimension(width, height));
		setMaximumSize(new Dimension(width, height));
	}
	
}	// Class Ends