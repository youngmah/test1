/*

  This class extends the default data model for the JTable component.  Overriding the 'isCellEditable()' method
  ensures that the user cannot edit the table data.

  Author - Steve Young. March 1999

*/

import javax.swing.table.AbstractTableModel;
import java.net.*;


class AccountHistoryTableModel extends AbstractTableModel {

	/*
			NB WARNING!!! NO. OF COLUMN NAMES MUST MATCH NO. OF DATA ENTRIES,
			OTHERWISE COLUMN HEADERS MAY NOT APPEAR.
	
			EVEN WORSE PROBLEMS ARE ENCOUNTERED IF TOO LITTLE DATA IS USED FOR EACH ROW,
			AS THIS RESULTS IN AN ARRAY INDEX OUT OF BOUNDS EXCEPTION!!!
	*/


	final String[] columnNames = {"Balance", "Billed", "Amount", "Paid", "Amount"};
	
        final Object[][] data = {	{"", "", "", "", ""},
					{"", "", "", "", ""},
					{"", "", "", "", ""},
				};


	public Object getValueAt(int row, int col){
		return data[row][col];
	}
	
	public String getColumnName(int column) {
		return columnNames[column];
	}
	
	public Class getColumnClass(int col) {
		return getValueAt(0,col).getClass();
	}

	public void setValueAt(Object aValue, int row, int column) {
		data[row][column] = aValue;
	}

	public int getRowCount() {
		return 3;	
	}
	
	public int getColumnCount() {
		return columnNames.length;
	}

	public boolean isCellEditable(int row, int column) {
		return false;
	}


}	// Class Ends