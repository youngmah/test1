/*

	Class to define an account record.  This class is instantiated once for every record  retrieved.

	The constructor takes a single string buffer as a parameter, which MUST be exactly 383 characters in length.

	Author - Steve Young. March 1999

*/

import java.io.*;


class AccountRecord {
	private final int recordLength = 383;
	private String accountNo;
	private String sName;
	private String fName;
	private String initial;
	private String title;
	private String phone;
	private String address1;
	private String address2;
	private String address3;
	private String authUser1;
	private String authUser2;
	private String authUser3;
	private String authUser4;
	private String cards;
	private String dateIssued;
	private String reason;
	private String cardCode;
	private String approvedBy;
	private String specialCode1;
	private String specialCode2;
	private String specialCode3;
	private String status;
	private String limit;
	private AccountHistory history1;
	private AccountHistory history2;
	private AccountHistory history3;
	
	// Constructor converts raw data buffer into specific class variables
	public AccountRecord(String rawData) {
		// Check for a valid buffer length
		if(rawData.length() != recordLength){
			System.err.println("Invalid record length of " + rawData.length() + ". Cannot create new AccountRecord object - closing");
			System.exit(1);
		}
	
		// Use char array to convert char to String via call to String constructor (see below)
		char[] temp = {' '};

		char tempChar[] = {' '};
		tempChar[0] = rawData.charAt(0);
		String tempString = new String(tempChar);	// String constructor requires char array NOT char

		accountNo = rawData.substring(0, 5);				// 5     Account number
		sName = rawData.substring(5, 23);					// 18    Surname
		fName = rawData.substring(23, 35);					// 12    First Name

		temp[0] = rawData.charAt(35);
		initial = new String(temp);							// 1     Middle Initial
		title = rawData.substring(36, 40);					// 4     Title e.g. Mr./Mrs./Dr.
		phone = rawData.substring(40, 50);					// 10    Telephone Number
		address1 = rawData.substring(50, 74);				// 24    Address field 1
		address2 = rawData.substring(74, 98);				// 24    Address field 2
		address3 = rawData.substring(98, 122);				// 24    Address field 3
		authUser1 = rawData.substring(122, 154);			// 32    Additional Authorised Card User 1
		authUser2 = rawData.substring(154, 186);			// 32    Additional Authorised Card User 2
		authUser3 = rawData.substring(186, 218);			// 32    Additional Authorised Card User 3
		authUser4 = rawData.substring(218, 250);			// 32    Additional Authorised Card User 4
	
		temp[0] = rawData.charAt(250);
		cards = new String(temp);					// 1     Number of cards issued to Customer
		dateIssued = rawData.substring(251, 253) + "-" +		// 6     Date card issued
					rawData.substring(253, 255) + "-" +	
					rawData.substring(255, 257);
		temp[0] = rawData.charAt(257);
		reason = new String(temp);					// 1     Reason code for card issue

		temp[0] = rawData.charAt(258);
		cardCode = new String(temp);					// 1     Card status Code e.g. G for Gold

		approvedBy = rawData.substring(259, 262);			// 3     Code of Card issue approver

		temp[0] = rawData.charAt(262);
		specialCode1 = new String(temp);				// 1     Additional Priviledge Code 1
	
		temp[0] = rawData.charAt(263);
		specialCode2 = new String(temp);				// 1     Additional Priviledge Code 2
		
		temp[0] = rawData.charAt(264);
		specialCode3 = new String(temp);				// 1     Additional Priviledge Code 3
	
		status = rawData.substring(265, 267);				// 2     Account Status
		limit = rawData.substring(267, 275);				// 8     Customer Account Credit Limit

		// Create new AccountHistory objects
		history1 = new AccountHistory(rawData.substring(275, 311));
		history2 = new AccountHistory(rawData.substring(311, 347));
		history3 = new AccountHistory(rawData.substring(347, 383));
	
	}

	
	// Retrieval Methods
	public String getAccountNo() {
		return accountNo;
	}

	public String getSName() {
		return sName;
	}

	public String getFName() {
		return fName;
	}

	public String getInitial() {
		return initial;
	}

	public String getTitle() {
		return title;
	}

	public String getPhone() {
		return phone;
	}

	public String getAddress1() {
		return address1;
	}

	public String getAddress2() {
		return address2;
	}

	public String getAddress3() {
		return address3;
	}

	public String getAuthUser1() {
		return authUser1;
	}

	public String getAuthUser2() {
		return authUser2;
	}

	public String getAuthUser3() {
		return authUser3;
	}

	public String getAuthUser4() {
		return authUser4;
	}

	public String getCards() {
		return cards;
	}

	public String getDateIssued() {
		return dateIssued;
	}
	
	public String getReason() {
		return reason;
	}

	public String getCardCode() {
		return cardCode;
	}

	public String getApprovedBy() {
		return approvedBy;
	}

	public String getSpecialCode1() {
		return specialCode1;
	}

	public String getSpecialCode2() {
		return specialCode2;
	}

	public String getSpecialCode3() {
		return specialCode3;
	}

	public String getStatus() {
		return status;
	}

	public String getLimit() {
		return limit;
	}

	public AccountHistory getHistory1() {
		return history1;
	}

	public AccountHistory getHistory2() {
		return history2;
	}

	public AccountHistory getHistory3() {
		return history3;
	}


}	// Class Ends
